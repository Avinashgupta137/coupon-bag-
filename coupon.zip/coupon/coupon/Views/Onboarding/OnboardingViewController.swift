//
//  OnboardingViewController.swift
//  coupon
//
//  Created by MAC OS on 21/01/22.
//

import UIKit

class OnboardingViewController: UIViewController {

    @IBOutlet var collectionView: UICollectionView!
    
    @IBOutlet var nextButton: UIButton!
    
    @IBOutlet var pagecontrol: UIPageControl!
    
    var slides: [OnboardingSlide] = []
    
    var currentPage = 0 {
        didSet {
            pagecontrol.currentPage = currentPage
            if currentPage == slides.count - 1{
                nextButton.setTitle("Get Started",for:.normal)
            }else{
                nextButton.setTitle("next", for: .normal)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        slides = [
                    OnboardingSlide(title: "Get more coupon", description: "enjoy it", image: #imageLiteral(resourceName: "coupon4")),
                    OnboardingSlide(title: "Get more coupon", description: "free reward", image: #imageLiteral(resourceName: "coupon2")),
                    OnboardingSlide(title: "Get more reward", description: "enjoy it", image: #imageLiteral(resourceName: "coupon1"))
                ]
        
    }
    

    @IBAction func nextBtnClicked(_ sender: UIButton)
    {
        if currentPage == slides.count - 1 {
            let controller = storyboard?.instantiateViewController(identifier: "HomeNC") as! UINavigationController
            controller.modalPresentationStyle = .fullScreen
            controller.modalTransitionStyle = .flipHorizontal
            present(controller , animated: true, completion: nil)
            
            
        }else {
        currentPage += 1
        let indexPath = IndexPath(item: currentPage, section: 0)
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    }

}

extension OnboardingViewController:
    UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return slides.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OnboardingCollectionViewCell.identifier, for: indexPath) as! OnboardingCollectionViewCell
        cell.setup(slides[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let width = scrollView.frame.width
        currentPage = Int(scrollView.contentOffset.x / width)
        
        pagecontrol.currentPage = currentPage
    }
}
