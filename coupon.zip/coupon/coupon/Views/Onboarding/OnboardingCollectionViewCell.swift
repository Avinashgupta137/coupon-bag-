//
//  OnboardingCollectionViewCell.swift
//  coupon
//
//  Created by MAC OS on 21/01/22.
//

import UIKit

class OnboardingCollectionViewCell: UICollectionViewCell {
    
    static let identifier = String(describing:OnboardingCollectionViewCell.self)
    
    @IBOutlet var slideimageview: UIImageView!
    @IBOutlet var slidtitlelabel: UILabel!
    
    
    
    func setup(_ slide: OnboardingSlide) {
        slideimageview.image = slide.image
        slidtitlelabel.text = slide.title
    }
}
