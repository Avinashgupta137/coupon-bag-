//
//  OnboaringSlide.swift
//  coupon
//
//  Created by MAC OS on 21/01/22.
//

import Foundation
import UIKit

struct OnboardingSlide {
    let title : String
    let description : String
    let image : UIImage
    
}
