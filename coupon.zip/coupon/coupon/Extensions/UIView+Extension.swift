//
//  UIView+Extension.swift
//  coupon
//
//  Created by MAC OS on 21/01/22.
//

import Foundation
import UIKit

extension UIView{
    @IBInspectable var  cornerRadious: CGFloat {
        get { return cornerRadious }
        set {
            self.layer.cornerRadius = newValue
        }
    }
}
