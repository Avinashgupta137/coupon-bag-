//
//  ViewController.swift
//  Coupon Bag
//
//  Created by MAC OS 17 on 20/01/22.
//

import UIKit

class ViewController: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var btnSignin: UIButton!
    @IBOutlet weak var btnSignup: UIButton!
    //MARK:- CLass Variables

    //MARK:- Custom Methods

    func setUpView() {
    }

    //MARK:- Action Methods

    //MARK:- View Controller Life Cycle

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
        // Do any additional setup after loading the view.
//        btnSignin.clipsToBounds = true
//        btnSignin.layer.cornerRadius = 20.0
//        let signin = CAGradientLayer()
//        signin.frame = btnSignin.bounds
        
//        btnSignin.layer.addSublayer(signin)
        
//        btnSignup.clipsToBounds = true
//        btnSignup.layer.cornerRadius = 20.0
//        let signup = CAGradientLayer()
//        signup.frame = btnSignup.bounds
//        signup.colors = [UIColor.systemYellow.cgColor,UIColor.systemPink.cgColor]
//        btnSignin.layer.addSublayer(signup)
        
        
    }

   

}

//MARK:- Extensions
