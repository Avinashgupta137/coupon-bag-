//
//  LoginViewController.swift
//  Coupon Bag
//
//  Created by MAC OS 17 on 20/01/22.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var txtEmail: UITextField!

    @IBOutlet weak var btnSignup: UIButton!
    @IBOutlet weak var btnForgetPassword: UIButton!
    @IBOutlet weak var btnSignin: UIButton!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//        txtEmail.layer.cornerRadius = 15.0
//        txtEmail.layer.borderWidth = 2.0
//       
//        txtEmail.layer.masksToBounds = true
//        txtPassword.text = "hello"

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
